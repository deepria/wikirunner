(function(){var e=[`namu.wiki`],t=[`파일`,`분류`,`file`,`category`],n=`/w/`,r=e=>({ok:!1,code:e});function i(i,o={}){let s;try{s=i instanceof URL?new URL(i.href):new URL(i)}catch{return r(`INVALID_URL`)}if(s.protocol!==`https:`)return r(`INSECURE_PROTOCOL`);if(s.username||s.password||s.port!==``&&s.port!==`443`)return r(`UNSUPPORTED_PORT`);if(!(o.allowedHosts??e).some(e=>e.toLowerCase()===s.hostname.toLowerCase()))return r(`UNSUPPORTED_HOST`);if(!s.pathname.startsWith(n))return r(`INVALID_PATH`);let c=s.pathname.slice(3);if(!c)return r(`EMPTY_ARTICLE`);let l;try{l=decodeURIComponent(c).normalize(`NFC`)}catch{return r(`INVALID_ENCODING`)}if(!l)return r(`EMPTY_ARTICLE`);if([...l].some(a))return r(`INVALID_ARTICLE`);let u=l.indexOf(`:`);if(u>0){let e=l.slice(0,u).trim().toLowerCase();if((o.excludedNamespaces??t).some(t=>t.toLowerCase()===e))return r(`EXCLUDED_NAMESPACE`)}return{ok:!0,articleKey:l,title:l,canonicalUrl:`https://${s.hostname.toLowerCase()}/w/${encodeURIComponent(l)}`}}function a(e){let t=e.codePointAt(0);return t!==void 0&&(t<=31||t===127)}function o(e,t,n){if(e){let t=i(e,n);if(t.ok)return t}return i(t,n)}var s=document.querySelector(`link[rel="canonical"]`)?.href,c=o(s,window.location.href);if(c.ok&&!document.querySelector(`#wikirunner-root`)){let e=c,t=document.createElement(`aside`);t.id=`wikirunner-root`,t.setAttribute(`aria-label`,`WikiRunner 경기 상태`);let n=t.attachShadow({mode:`closed`});n.innerHTML=`
    <style>
      :host {
        all: initial;
        position: fixed;
        z-index: 2147483647;
        top: 18px;
        right: 18px;
        color: #f4f1e8;
        font-family: Arial, "Apple SD Gothic Neo", sans-serif;
      }
      section {
        width: 220px;
        border: 1px solid #d9ff43;
        background: #191b1a;
        box-shadow: 5px 5px 0 rgb(217 255 67 / 45%);
      }
      header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 12px;
        border-bottom: 1px solid #4c4f4c;
      }
      .finish-banner {
        display: grid;
        gap: 3px;
        padding: 12px;
        border-bottom: 1px solid #4c4f4c;
        background: #d9ff43;
        color: #191b1a;
      }
      .finish-banner strong {
        color: inherit;
        font-size: 16px;
      }
      .finish-banner span {
        font-size: 11px;
        font-weight: 700;
      }
      .fair-play-notice {
        padding: 9px 12px;
        border-bottom: 1px solid #4c4f4c;
        background: #a32314;
        color: #fff;
        font-size: 11px;
        font-weight: 700;
        line-height: 1.4;
      }
      strong {
        color: #d9ff43;
        font-size: 13px;
        letter-spacing: -0.3px;
      }
      button {
        border: 0;
        color: #f4f1e8;
        background: transparent;
        cursor: pointer;
      }
      dl {
        display: grid;
        grid-template-columns: 48px 1fr;
        gap: 8px;
        margin: 0;
        padding: 12px;
        font-size: 12px;
      }
      dt {
        color: #92968f;
      }
      dd {
        overflow: hidden;
        margin: 0;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      section[data-collapsed="true"] dl {
        display: none;
      }
      section[data-collapsed="true"] .finish-banner,
      section[data-collapsed="true"] .fair-play-notice {
        display: none;
      }
    </style>
    <section>
      <header>
        <strong>WikiRunner</strong>
        <button type="button" aria-label="오버레이 접기" aria-expanded="true">접기</button>
      </header>
      <div class="finish-banner" id="finish-banner" hidden role="status" aria-live="polite">
        <strong id="finish-title">경기 진행중.. 달리세요!</strong>
        <span id="finish-detail">완주 기록을 전송 중입니다.</span>
      </div>
      <div class="fair-play-notice" id="fair-play-notice" hidden role="status" aria-live="polite"></div>
      <dl>
        <dt>현재</dt><dd id="current-article" title="${h(c.title)}">${h(c.title)}</dd>
        <dt>목표</dt><dd id="target">연결 대기</dd>
        <dt>시간</dt><dd id="timer">--:--.--</dd>
        <dt>이동</dt><dd id="move-count">0회</dd>
        <dt>상태</dt><dd id="game-status">미연결</dd>
      </dl>
    </section>
  `;let r=n.querySelector(`section`),a=n.querySelector(`button`);a?.addEventListener(`click`,()=>{let e=r?.dataset.collapsed!==`true`;r&&(r.dataset.collapsed=String(e)),a.textContent=e?`펼치기`:`접기`,a.setAttribute(`aria-label`,e?`오버레이 펼치기`:`오버레이 접기`),a.setAttribute(`aria-expanded`,String(!e))}),document.documentElement.append(t);let o=n.querySelector(`#current-article`),s=n.querySelector(`#target`),x=n.querySelector(`#timer`),S=n.querySelector(`#move-count`),C=n.querySelector(`#game-status`),w=n.querySelector(`#finish-banner`),T=n.querySelector(`#finish-title`),E=n.querySelector(`#finish-detail`),D=n.querySelector(`#fair-play-notice`),O,k,A,j,M,N=!1,P,F,I=()=>{if(!o||!s||!x||!S||!C||!w||!T||!E)return;if(o.textContent=e.title,o.title=e.title,!O){s.textContent=`연결 대기`,x.textContent=`--:--.--`,S.textContent=`0회`;let t=j?.outcome===`finished`&&M?.targetArticleKey===e.articleKey;w.hidden=!t,t&&M?(T.textContent=`완주 기록 완료!`,E.textContent=`${M.targetArticleTitle}에 도착했습니다.`,C.textContent=`완주`):C.textContent=`미연결`;return}s.textContent=O.targetArticleTitle,s.title=O.targetArticleTitle,S.textContent=`${k?.moveCount??0}회`;let t=new Date(O.scheduledAt).getTime(),n=Date.now()-t;if(n<0){w.hidden=!0,x.textContent=`-${Math.ceil(Math.abs(n)/1e3)}초`,C.textContent=`카운트다운`;return}x.textContent=g(n);let r=(k?.lastSequence??0)>0&&e.articleKey===O.targetArticleKey&&k?.lastArticleKey===O.targetArticleKey;w.hidden=!r,r&&(A?(T.textContent=`경기 진행중.. 달리세요!`,E.textContent=`완주 기록 전송을 다시 시도하고 있습니다.`):k?.status===`finished`?(T.textContent=`완주 기록 완료!`,E.textContent=`기록이 서버에 저장되었습니다.`):(T.textContent=`경기 진행중.. 달리세요!`,E.textContent=`완주 기록을 전송 중입니다.`)),C.textContent=A?`기록 전송 오류`:k?.status===`finished`?`완주`:k?.violationStatus===`warned`?`진행 중 · 경고 있음`:`진행 중`,C.title=A??``};chrome.storage.local.get([`activeGame`,`activeRun`,`lastEventError`,`lastGameOutcome`,`lastCompletedGame`]).then(({activeGame:e,activeRun:t,lastEventError:n,lastGameOutcome:r,lastCompletedGame:i})=>{O=_(e)?e:void 0,k=v(t)?t:void 0,A=typeof n==`string`?n:void 0,j=y(r)?r:void 0,M=b(i)?i:void 0,I()}),chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&(e.activeGame&&(O=_(e.activeGame.newValue)?e.activeGame.newValue:void 0),e.activeRun&&(k=v(e.activeRun.newValue)?e.activeRun.newValue:void 0),e.lastEventError&&(A=typeof e.lastEventError.newValue==`string`?e.lastEventError.newValue:void 0),e.lastGameOutcome&&(j=y(e.lastGameOutcome.newValue)?e.lastGameOutcome.newValue:void 0),e.lastCompletedGame&&(M=b(e.lastCompletedGame.newValue)?e.lastCompletedGame.newValue:void 0),I(),(e.activeGame||e.gameTabId)&&L())});async function L(){try{let e=await chrome.runtime.sendMessage({type:`GET_FAIR_PLAY_STATE`});N=typeof e==`object`&&!!e&&e.enabled===!0}catch{N=!1}l()}function l(){if(document.documentElement.classList.toggle(`wikirunner-fair-play-active`,N),!N)for(let e of document.querySelectorAll(`.wikirunner-fair-play-blocked-link`))e.classList.remove(`wikirunner-fair-play-blocked-link`);let e=document.querySelector(`#app > div > div:first-child, body > header`);e?.querySelector(`input[type="search"], a[href="/random"]`)&&e.classList.toggle(`wikirunner-fair-play-hidden`,N);for(let e of u())e.classList.toggle(`wikirunner-fair-play-hidden`,N);for(let e of document.querySelectorAll(`input[type="search"], a[href="/random"], a[title="검색"], a[title="아무 문서로 이동"]`))((e.matches(`input[type="search"]`)?e.closest(`form`)?.parentElement:e.closest(`a`))??e).classList.toggle(`wikirunner-fair-play-hidden`,N);for(let e of document.querySelectorAll(`a`))e.textContent?.replaceAll(/\s+/g,``).includes(`실시간검색어`)&&(e.closest(`li`)??e).classList.toggle(`wikirunner-fair-play-hidden`,N)}function u(){let e=new Set;for(let t of[`실시간 랭킹`,`실시간 검색어`,`인기 문서`,`최근 변경`])for(let n of document.querySelectorAll(`a, span, strong, p, li, h1, h2, h3, h4, h5, h6, div`)){if(!(n.textContent?.replaceAll(/\s+/g,``)??``).includes(t.replaceAll(/\s+/g,``)))continue;let r=d(n,t);r&&e.add(r)}return[...e]}function d(e,t){let n=document.querySelector(`article`),r=t.replaceAll(/\s+/g,``).length,i=e;for(let e=0;i&&e<8;e+=1){let e=i.getBoundingClientRect(),t=(i.textContent??``).replaceAll(/\s+/g,``).length;if(!i.contains(n)&&e.width>120&&e.width<520&&e.height>=80&&t>r+2&&e.left>=window.innerWidth*.55)return i;i=i.parentElement}return null}function f(e){D&&(D.textContent=e,D.hidden=!1,P!==void 0&&window.clearTimeout(P),P=window.setTimeout(()=>{D.hidden=!0},3e3))}function p(){chrome.runtime.sendMessage({type:`FAIR_PLAY_BLOCKED`,violationType:`search_attempt`})}function m(e){if(e.closest(`input[type="search"]`))return`경기 중에는 문서 검색을 사용할 수 없습니다.`;let t=e.closest(`a`);if(!t)return;let n=t.getAttribute(`href`)??``,r=t.getAttribute(`title`)??``;if(n===`/random`||/^\/(?:Search|search)(?:[/?#]|$)/.test(n)||r===`검색`||r===`아무 문서로 이동`)return`경기 중에는 검색과 랜덤 문서 이동을 사용할 수 없습니다.`;let i=n;try{i=decodeURIComponent(n)}catch{}if(i.startsWith(`/w/분류:`)||t.closest(`[class*="category" i], [id*="category" i]`))return`경기 중에는 분류 링크를 사용할 수 없습니다.`;let a=document.querySelector(`article`);if(!t.closest(`article`)&&(t.closest(`header, nav, aside, [role='navigation'], [role='complementary']`)||a!==null&&!a.contains(t)))return`경기 중에는 본문 링크만 사용할 수 있습니다.`}document.addEventListener(`click`,e=>{if(!N||!(e.target instanceof Element)||!m(e.target))return;let t=m(e.target);t&&(e.preventDefault(),e.stopImmediatePropagation(),p(),f(t))},{capture:!0}),document.addEventListener(`pointerover`,e=>{if(!N||!(e.target instanceof Element))return;let t=e.target.closest(`a`),n=t?m(t):void 0;!t||!n||(t.classList.add(`wikirunner-fair-play-blocked-link`),f(n))},{capture:!0}),document.addEventListener(`submit`,e=>{!N||!(e.target instanceof HTMLFormElement)||e.target.querySelector(`input[type="search"]`)&&(e.preventDefault(),e.stopImmediatePropagation(),p(),f(`경기 중에는 문서 검색을 사용할 수 없습니다.`))},{capture:!0}),document.addEventListener(`keydown`,e=>{if(!N)return;let t=e.target instanceof Element?e.target:null,n=t?.matches(`input[type="search"]`)??!1,r=(e.ctrlKey||e.metaKey)&&e.key.toLowerCase()===`k`,i=(e.ctrlKey||e.metaKey)&&e.key.toLowerCase()===`f`,a=e.key===`/`&&!t?.matches(`input, textarea, [contenteditable=true]`);!n&&!r&&!i&&!a||(e.preventDefault(),e.stopImmediatePropagation(),p(),f(i?`경기 중에는 브라우저 찾기 기능을 사용할 수 없습니다.`:`경기 중에는 문서 검색 단축키를 사용할 수 없습니다.`))},{capture:!0});let R=document.createElement(`style`);R.textContent=`
    .wikirunner-fair-play-hidden { display: none !important; }
    .wikirunner-fair-play-blocked-link {
      cursor: not-allowed !important;
      text-decoration: line-through !important;
    }
  `,document.documentElement.append(R),new MutationObserver(()=>{F===void 0&&(F=window.setTimeout(()=>{F=void 0,l()},50))}).observe(document.documentElement,{childList:!0,subtree:!0}),L(),document.addEventListener(`click`,t=>{let n=t.target instanceof Element?t.target.closest(`a`):null;if(!n||!O||Date.now()<new Date(O.scheduledAt).getTime())return;let r=i(n.href);r.ok&&chrome.runtime.sendMessage({type:`LINK_INTENT`,fromArticleKey:e.articleKey,toArticleKey:r.articleKey,observedAt:new Date().toISOString()})},{capture:!0}),window.setInterval(()=>{let t=i(window.location.href);if(t.ok&&t.articleKey!==e.articleKey){let n=e;e=t,chrome.runtime.sendMessage({type:`PAGE_NAVIGATION_OBSERVED`,fromArticleKey:n.articleKey,articleKey:t.articleKey,observedAt:new Date().toISOString()})}I()},100)}function h(e){return e.replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`).replaceAll(`'`,`&#039;`)}function g(e){let t=Math.floor(e/6e4),n=Math.floor(e%6e4/1e3),r=Math.floor(e%1e3/10);return`${String(t).padStart(2,`0`)}:${String(n).padStart(2,`0`)}.${String(r).padStart(2,`0`)}`}function _(e){if(typeof e!=`object`||!e)return!1;let t=e;return typeof t.scheduledAt==`string`&&typeof t.targetArticleKey==`string`&&typeof t.targetArticleTitle==`string`}function v(e){if(typeof e!=`object`||!e)return!1;let t=e;return(t.status===`waiting`||t.status===`running`||t.status===`finished`)&&typeof t.lastSequence==`number`&&typeof t.lastArticleKey==`string`&&typeof t.moveCount==`number`&&(t.violationStatus===`clear`||t.violationStatus===`warned`||t.violationStatus===`reviewed`)}function y(e){if(typeof e!=`object`||!e)return!1;let t=e;return(t.outcome===`finished`||t.outcome===`abandoned`)&&typeof t.occurredAt==`string`}function b(e){if(typeof e!=`object`||!e)return!1;let t=e;return typeof t.targetArticleKey==`string`&&typeof t.targetArticleTitle==`string`}})();